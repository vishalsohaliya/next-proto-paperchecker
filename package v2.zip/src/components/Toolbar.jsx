export default function Toolbar({
  tool,
  onTool,
  onUploadClick,
  onStampClick,
  onSaveJson,
  onLoadJsonClick,
  onExportPng,
  onExportPdf,
  docLoaded,
  pageLabel,
  onPrev,
  onNext,
  zoom,
  onZoom,
}) {
  return (
    <header className="toolbar">
      <button type="button" onClick={onUploadClick}>
        Upload file
      </button>
      <span className="sep" />
      <button type="button" className={tool === 'select' ? 'active' : ''} onClick={() => onTool('select')}>
        Select
      </button>
      <button type="button" className={tool === 'text' ? 'active' : ''} onClick={() => onTool('text')}>
        Add text
      </button>
      <button type="button" className={tool === 'draw' ? 'active' : ''} onClick={() => onTool('draw')}>
        Draw
      </button>
      <button type="button" className={tool === 'rect' ? 'active' : ''} onClick={() => onTool('rect')}>
        Rectangle
      </button>
      <button type="button" className={tool === 'circle' ? 'active' : ''} onClick={() => onTool('circle')}>
        Circle
      </button>
      <button type="button" className={tool === 'stamp' ? 'active' : ''} onClick={onStampClick}>
        Add image
      </button>
      <span className="sep" />
      <button type="button" onClick={onSaveJson} disabled={!docLoaded}>
        Save JSON
      </button>
      <button type="button" onClick={onLoadJsonClick} disabled={!docLoaded}>
        Load JSON
      </button>
      <span className="sep" />
      <button type="button" onClick={() => onZoom(zoom - 0.1)} disabled={!docLoaded}>
        Zoom −
      </button>
      <span className="hint">{Math.round(zoom * 100)}%</span>
      <button type="button" onClick={() => onZoom(zoom + 0.1)} disabled={!docLoaded}>
        Zoom +
      </button>
      <span className="sep" />
      <button type="button" onClick={onExportPng} disabled={!docLoaded}>
        Export PNG
      </button>
      <button type="button" onClick={onExportPdf} disabled={!docLoaded}>
        Export PDF
      </button>
      {pageLabel ? (
        <>
          <span className="sep" />
          <div className="pager" style={{ margin: 0 }}>
            <button type="button" onClick={onPrev}>
              Prev
            </button>
            <span className="hint">{pageLabel}</span>
            <button type="button" onClick={onNext}>
              Next
            </button>
          </div>
        </>
      ) : null}
      <span className="sep" />
      <span className="hint">Delete / Backspace removes selection</span>
    </header>
  );
}
