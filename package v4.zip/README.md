﻿# next-proto-paperchecker
