import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { Canvas, PencilBrush, IText, Rect, Ellipse, FabricImage } from 'fabric';

const CROSSHAIR_TOOLS = ['text', 'stamp', 'rect', 'circle'];

const AnnotationLayer = forwardRef(function AnnotationLayer(
  { width, height, tool, stampUrl, onStampConsumed, zoom, initialJson },
  ref,
) {
  const lowerRef = useRef(null);
  const fabricRef = useRef(null);

  // Keep mutable refs for values used inside stable closures
  const toolRef = useRef(tool);
  const stampUrlRef = useRef(stampUrl);
  const onStampConsumedRef = useRef(onStampConsumed);
  const zoomRef = useRef(zoom);
  const widthRef = useRef(width);
  const heightRef = useRef(height);

  toolRef.current = tool;
  stampUrlRef.current = stampUrl;
  onStampConsumedRef.current = onStampConsumed;
  zoomRef.current = zoom;
  widthRef.current = width;
  heightRef.current = height;

  useImperativeHandle(ref, () => ({
    getFabric() {
      return fabricRef.current;
    },
    toJSON() {
      const json = fabricRef.current?.toJSON() ?? { objects: [] };
      const { viewportTransform: _vt, ...rest } = json;
      return rest;
    },
    async loadJSON(json) {
      const c = fabricRef.current;
      if (!c) return;
      const safe = { ...(json ?? { objects: [] }) };
      delete safe.viewportTransform;
      await c.loadFromJSON(safe);
      const z = zoomRef.current;
      c.setZoom(z);
      c.setDimensions({ width: widthRef.current * z, height: heightRef.current * z });
      c.requestRenderAll();
    },
    calcOffset() {
      fabricRef.current?.calcOffset();
    },
  }));

  // Apply zoom via Fabric viewport — keeps annotations sharp at every level
  useEffect(() => {
    const canvas = fabricRef.current;
    if (!canvas || !width || !height) return;
    canvas.setZoom(zoom);
    canvas.setDimensions({ width: width * zoom, height: height * zoom });
    canvas.requestRenderAll();
  }, [zoom, width, height]);

  // Sync tool mode without recreating the canvas
  useEffect(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    canvas.isDrawingMode = tool === 'draw';
    canvas.selection = tool !== 'draw';
    canvas.defaultCursor = CROSSHAIR_TOOLS.includes(tool) ? 'crosshair' : 'default';
    canvas.skipTargetFind = tool === 'draw';
    canvas.requestRenderAll();
  }, [tool]);

  // Canvas creation — only re-runs when base pixel dimensions change
  useEffect(() => {
    if (!width || !height || !lowerRef.current) return;

    const canvas = new Canvas(lowerRef.current, {
      width,
      height,
      preserveObjectStacking: true,
      enableRetinaScaling: true,
    });
    fabricRef.current = canvas;

    const brush = new PencilBrush(canvas);
    brush.color = '#111827';
    brush.width = 2;
    canvas.freeDrawingBrush = brush;

    canvas.isDrawingMode = false;
    canvas.selection = true;

    let drawingShape = false;
    let origX = 0;
    let origY = 0;
    let shapeInProgress = null;

    const onMouseDown = (opt) => {
      const t = toolRef.current;
      const { x, y } = opt.scenePoint;

      if (t === 'stamp' && stampUrlRef.current && !opt.target) {
        FabricImage.fromURL(stampUrlRef.current).then((img) => {
          const maxSide = 200;
          const scale = Math.min(maxSide / (img.width || 1), maxSide / (img.height || 1), 1);
          img.set({ left: x, top: y, scaleX: scale, scaleY: scale });
          canvas.add(img);
          canvas.setActiveObject(img);
          canvas.requestRenderAll();
          onStampConsumedRef.current?.();
        });
        return;
      }

      if (t === 'text' && !opt.target) {
        const text = new IText('Text', {
          left: x,
          top: y,
          fontSize: 18,
          fill: '#111827',
        });
        canvas.add(text);
        canvas.setActiveObject(text);
        canvas.requestRenderAll();
        return;
      }

      if ((t === 'rect' || t === 'circle') && !opt.target) {
        drawingShape = true;
        origX = x;
        origY = y;
        if (t === 'rect') {
          shapeInProgress = new Rect({
            left: origX,
            top: origY,
            width: 0,
            height: 0,
            fill: 'rgba(37,99,235,0.12)',
            stroke: '#2563eb',
            strokeWidth: 2,
            strokeUniform: true,
          });
        } else {
          shapeInProgress = new Ellipse({
            left: origX,
            top: origY,
            rx: 0,
            ry: 0,
            fill: 'rgba(37,99,235,0.12)',
            stroke: '#2563eb',
            strokeWidth: 2,
            strokeUniform: true,
          });
        }
        canvas.add(shapeInProgress);
      }
    };

    const onMouseMove = (opt) => {
      if (!drawingShape || !shapeInProgress) return;
      const { x, y } = opt.scenePoint;
      const w = Math.abs(x - origX);
      const h = Math.abs(y - origY);
      const left = Math.min(origX, x);
      const top = Math.min(origY, y);
      if (shapeInProgress.type === 'ellipse') {
        shapeInProgress.set({ left, top, rx: w / 2, ry: h / 2 });
      } else {
        shapeInProgress.set({ left, top, width: w, height: h });
      }
      canvas.requestRenderAll();
    };

    const onMouseUp = () => {
      drawingShape = false;
      shapeInProgress = null;
    };

    canvas.on('mouse:down', onMouseDown);
    canvas.on('mouse:move', onMouseMove);
    canvas.on('mouse:up', onMouseUp);

    const onKeyDown = (e) => {
      if (e.key !== 'Delete' && e.key !== 'Backspace') return;
      const active = canvas.getActiveObject();
      if (!active) return;
      if (active instanceof IText && active.isEditing) return;
      canvas.remove(active);
      canvas.discardActiveObject();
      canvas.requestRenderAll();
    };
    window.addEventListener('keydown', onKeyDown);

    // Load existing annotations and apply current zoom after load
    const boot = { ...(initialJson ?? { objects: [] }) };
    delete boot.viewportTransform;
    canvas.loadFromJSON(boot).then(() => {
      const z = zoomRef.current;
      canvas.setZoom(z);
      canvas.setDimensions({ width: widthRef.current * z, height: heightRef.current * z });
      canvas.requestRenderAll();
    });

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      canvas.off('mouse:down', onMouseDown);
      canvas.off('mouse:move', onMouseMove);
      canvas.off('mouse:up', onMouseUp);
      canvas.dispose();
      fabricRef.current = null;
    };
    // initialJson intentionally omitted — it's a one-time seed value; the component
    // remounts (via annotationKey) whenever a fresh seed is needed.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [width, height]);

  if (!width || !height) return null;

  return (
    <div className="fabricSlot" style={{ width: width * zoom, height: height * zoom }}>
      <canvas ref={lowerRef} width={width} height={height} />
    </div>
  );
});

export default AnnotationLayer;
