import { forwardRef, useEffect, useImperativeHandle, useRef } from 'react';
import { Canvas, PencilBrush, IText, Rect, FabricImage } from 'fabric';

/**
 * Fabric canvas matches the background layer pixel-for-pixel (separate DOM layers, never merged).
 */
const AnnotationLayer = forwardRef(function AnnotationLayer(
  { width, height, tool, stampUrl, onStampConsumed, zoom, initialJson },
  ref,
) {
  const lowerRef = useRef(null);
  const fabricRef = useRef(null);
  const toolRef = useRef(tool);
  const stampUrlRef = useRef(stampUrl);
  toolRef.current = tool;
  stampUrlRef.current = stampUrl;

  useImperativeHandle(ref, () => ({
    getFabric() {
      return fabricRef.current;
    },
    toJSON() {
      return fabricRef.current?.toJSON() ?? { objects: [] };
    },
    async loadJSON(json) {
      const c = fabricRef.current;
      if (!c) return;
      await c.loadFromJSON(json ?? { objects: [] });
      c.requestRenderAll();
    },
    calcOffset() {
      fabricRef.current?.calcOffset();
    },
  }));

  useEffect(() => {
    fabricRef.current?.calcOffset();
  }, [zoom]);

  useEffect(() => {
    if (!width || !height || !lowerRef.current) return;

    const el = lowerRef.current;
    const canvas = new Canvas(el, {
      width,
      height,
      preserveObjectStacking: true,
      enableRetinaScaling: true,
    });
    fabricRef.current = canvas;

    const brush = new PencilBrush(canvas);
    brush.color = '#111827';
    brush.width = 2;
    canvas.freeDrawingBrush = brush;

    const applyTool = () => {
      const t = toolRef.current;
      canvas.isDrawingMode = t === 'draw';
      canvas.selection = t !== 'draw';
      canvas.defaultCursor = t === 'text' || t === 'stamp' ? 'crosshair' : 'default';
      canvas.skipTargetFind = t === 'draw';
    };
    applyTool();

    let drawRect = false;
    let origX = 0;
    let origY = 0;
    let rect = null;

    const onMouseDown = (opt) => {
      const t = toolRef.current;
      const { x, y } = opt.scenePoint;

      if (t === 'stamp' && stampUrlRef.current && !opt.target) {
        const url = stampUrlRef.current;
        FabricImage.fromURL(url).then((img) => {
          const scale = Math.min(120 / (img.width || 1), 80 / (img.height || 1), 1);
          img.set({ left: x, top: y, scaleX: scale, scaleY: scale });
          canvas.add(img);
          canvas.setActiveObject(img);
          canvas.requestRenderAll();
          onStampConsumed?.();
        });
        return;
      }

      if (t === 'text' && !opt.target) {
        const text = new IText('Text', {
          left: x,
          top: y,
          fontSize: 18,
          fill: '#111827',
        });
        canvas.add(text);
        canvas.setActiveObject(text);
        canvas.requestRenderAll();
        return;
      }

      if (t === 'rect' && !opt.target) {
        drawRect = true;
        origX = x;
        origY = y;
        rect = new Rect({
          left: origX,
          top: origY,
          width: 0,
          height: 0,
          fill: 'rgba(37,99,235,0.12)',
          stroke: '#2563eb',
          strokeWidth: 2,
        });
        canvas.add(rect);
      }
    };

    const onMouseMove = (opt) => {
      if (!drawRect || !rect) return;
      const { x, y } = opt.scenePoint;
      rect.set({
        width: Math.abs(x - origX),
        height: Math.abs(y - origY),
        left: Math.min(origX, x),
        top: Math.min(origY, y),
      });
      canvas.requestRenderAll();
    };

    const onMouseUp = () => {
      drawRect = false;
      rect = null;
    };

    canvas.on('mouse:down', onMouseDown);
    canvas.on('mouse:move', onMouseMove);
    canvas.on('mouse:up', onMouseUp);

    const onKeyDown = (e) => {
      if (e.key !== 'Delete' && e.key !== 'Backspace') return;
      const active = canvas.getActiveObject();
      if (!active) return;
      if (active instanceof IText && active.isEditing) return;
      canvas.remove(active);
      canvas.discardActiveObject();
      canvas.requestRenderAll();
    };
    window.addEventListener('keydown', onKeyDown);

    const boot = initialJson ?? { objects: [] };
    canvas.loadFromJSON(boot).then(() => {
      canvas.requestRenderAll();
      canvas.calcOffset();
    });

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      canvas.off('mouse:down', onMouseDown);
      canvas.off('mouse:move', onMouseMove);
      canvas.off('mouse:up', onMouseUp);
      canvas.dispose();
      fabricRef.current = null;
    };
  }, [width, height, onStampConsumed]);

  useEffect(() => {
    const canvas = fabricRef.current;
    if (!canvas) return;
    const t = tool;
    canvas.isDrawingMode = t === 'draw';
    canvas.selection = t !== 'draw';
    canvas.defaultCursor = t === 'text' || t === 'stamp' ? 'crosshair' : 'default';
    canvas.skipTargetFind = t === 'draw';
    canvas.requestRenderAll();
  }, [tool]);

  if (!width || !height) return null;

  return (
    <div className="fabricSlot" style={{ width, height }}>
      <canvas ref={lowerRef} width={width} height={height} />
    </div>
  );
});

export default AnnotationLayer;
